package u9;

public class EmptyQueueException extends RuntimeException {
}
