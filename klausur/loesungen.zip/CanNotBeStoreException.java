package klausur;

public class CanNotBeStoreException extends Exception {
}
