package klausur;

public class EmptyBoxException extends Exception {
}
