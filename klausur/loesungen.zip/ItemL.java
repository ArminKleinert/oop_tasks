package klausur;

public class ItemL {
    int width; int height; int depth;

    public ItemL(int width, int height, int depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
    }
}
